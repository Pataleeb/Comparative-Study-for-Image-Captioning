"""
Central configuration for the image captioning project.
All hyperparameters and paths are defined here so experiments are reproducible.
"""
import os
import torch

# Reproducibility
SEED = 42

# Device
DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# Paths (default Colab layout - override via env vars when needed)
BASE_DIR = os.environ.get("COCO_BASE_DIR", "/content/data/coco")
DRIVE_ROOT = os.environ.get("DRIVE_ROOT", "/content/drive/MyDrive")
RESULTS_DIR = os.environ.get("RESULTS_DIR", "/content/results_captioning")
os.makedirs(RESULTS_DIR, exist_ok=True)

TRAIN_IMAGES_DIR = os.path.join(BASE_DIR, "train2017")
VAL_IMAGES_DIR = os.path.join(BASE_DIR, "val2017")
TRAIN_ANNOT_PATH = os.path.join(BASE_DIR, "annotations", "captions_train2017.json")
VAL_ANNOT_PATH = os.path.join(BASE_DIR, "annotations", "captions_val2017.json")

# Data
SUBSET_IMAGES = 40000          # Sampled from train2017
TRAIN_SUBSET_SIZE = 20000      # Final training pairs
VAL_SUBSET_SIZE = 2000         # Final validation pairs
TEST_SUBSET_SIZE = 2000        # Final test pairs (drawn from val2017)
VOCAB_SIZE = 10000
SPECIAL_TOKENS = ["<pad>", "<start>", "<end>", "<unk>"]
IMAGE_SIZE = 224
IMAGENET_MEAN = [0.485, 0.456, 0.406]
IMAGENET_STD = [0.229, 0.224, 0.225]
BATCH_SIZE = 32
NUM_WORKERS = 2

# Inference
MAX_CAPTION_LEN = 20
BEAM_SIZE_DEFAULT = 3

# Baseline LSTM hyperparameters
BASELINE_CONFIG = {
    "embed_dim": 512,
    "hidden_dim": 768,
    "num_layers": 1,
    "dropout": 0.5,
    "lr": 1e-3,
    "weight_decay": 1e-5,
    "num_epochs": 10,
    "model_name": "baseline_lstm",
}

# Attention LSTM hyperparameters
ATTENTION_CONFIG = {
    "attention_dim": 512,
    "embed_dim": 256,
    "decoder_dim": 768,
    "encoder_dim": 2048,
    "encoded_image_size": 14,
    "dropout": 0.5,
    "lr": 1e-3,
    "num_epochs": 10,
    "model_name": "attention_lstm",
}

# Transformer hyperparameters
TRANSFORMER_CONFIG = {
    "d_model": 256,
    "nhead": 8,
    "num_layers": 3,
    "dim_feedforward": 512,
    "dropout": 0.1,
    "max_len": 50,
    "lr": 1e-4,
    "weight_decay": 1e-5,
    "num_epochs": 10,
    "fine_tune_encoder": False,
    "model_name": "transformer",
}

# Data efficiency regimes
DATA_REGIMES = [0.1, 0.5, 1.0]
