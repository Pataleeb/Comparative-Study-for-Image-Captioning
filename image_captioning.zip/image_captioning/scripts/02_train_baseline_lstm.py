"""
Script 02: Train the baseline LSTM captioning model.

Usage (from project root):
    python -m scripts.02_train_baseline_lstm
"""
import os
import sys
import torch
import torch.nn as nn

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from config import DEVICE, RESULTS_DIR, BASELINE_CONFIG
from src.utils.helpers import set_seed
from src.data.loaders import prepare_datasets, build_dataloaders
from src.models.baseline_lstm import BaselineCaptioningModel
from src.training.train_baseline import train_baseline_model
from src.utils.plotting import plot_training_curve


def main():
    set_seed(42)

    print("Preparing data...")
    train_dataset, val_full_dataset, word2idx, idx2word = prepare_datasets()
    train_loader, val_loader, _, _ = build_dataloaders(
        train_dataset, val_full_dataset, word2idx
    )

    vocab_size = len(word2idx)
    pad_idx = word2idx["<pad>"]

    print(f"Initializing baseline LSTM | vocab={vocab_size} | device={DEVICE}")
    model = BaselineCaptioningModel(
        embed_dim=BASELINE_CONFIG["embed_dim"],
        hidden_dim=BASELINE_CONFIG["hidden_dim"],
        vocab_size=vocab_size,
        num_layers=BASELINE_CONFIG["num_layers"],
        dropout=BASELINE_CONFIG["dropout"],
    ).to(DEVICE)

    criterion = nn.CrossEntropyLoss(ignore_index=pad_idx)
    optimizer = torch.optim.Adam(
        filter(lambda p: p.requires_grad, model.parameters()),
        lr=BASELINE_CONFIG["lr"],
        weight_decay=BASELINE_CONFIG["weight_decay"],
    )

    save_path = os.path.join(RESULTS_DIR, "baseline_lstm_best.pth")
    history = {"train_losses": [], "val_losses": []}

    best_val_loss = train_baseline_model(
        model=model,
        train_loader=train_loader,
        val_loader=val_loader,
        criterion=criterion,
        optimizer=optimizer,
        device=DEVICE,
        num_epochs=BASELINE_CONFIG["num_epochs"],
        save_path=save_path,
        results_dict=history,
    )

    print(f"\nBest baseline LSTM validation loss: {best_val_loss:.4f}")

    plot_training_curve(
        history["train_losses"], history["val_losses"],
        title="Baseline LSTM Training vs Validation Loss",
        save_path=os.path.join(RESULTS_DIR, "baseline_loss_curve.png"),
    )


if __name__ == "__main__":
    main()
