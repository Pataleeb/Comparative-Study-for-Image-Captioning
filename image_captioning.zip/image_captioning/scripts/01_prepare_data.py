"""
Script 01: Download MS COCO data, build vocabulary, save splits.

Run this once before training. After this, train/val/test loaders are
fully reproducible from `prepare_datasets()` + `build_dataloaders()`.

Usage (from project root):
    python -m scripts.01_prepare_data
"""
import os
import sys
import json
import torch

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from config import RESULTS_DIR
from src.utils.helpers import set_seed
from src.data.loaders import prepare_datasets, build_dataloaders


def main():
    set_seed(42)

    print("Loading and preparing datasets...")
    train_dataset, val_full_dataset, word2idx, idx2word = prepare_datasets()

    print(f"Vocabulary size: {len(word2idx)}")
    print(f"PAD={word2idx['<pad>']} START={word2idx['<start>']} "
          f"END={word2idx['<end>']} UNK={word2idx['<unk>']}")
    print(f"Train pairs: {len(train_dataset)}")
    print(f"Val pairs:   {len(val_full_dataset)}")

    train_loader, val_loader, test_loader, _ = build_dataloaders(
        train_dataset, val_full_dataset, word2idx
    )
    print(f"Train batches: {len(train_loader)}")
    print(f"Val batches:   {len(val_loader)}")
    print(f"Test batches:  {len(test_loader)}")

    # Save vocab so other scripts can reload without rebuilding
    vocab_path = os.path.join(RESULTS_DIR, "vocab.json")
    with open(vocab_path, "w", encoding="utf-8") as f:
        json.dump({"word2idx": word2idx}, f)
    print(f"Saved vocabulary to {vocab_path}")


if __name__ == "__main__":
    main()
