"""
Script 05: Evaluate all three trained models on the held-out test set.

Computes:
  - Test loss + perplexity
  - BLEU 1-4 (greedy decoding)

Usage (from project root):
    python -m scripts.05_evaluate_models
"""
import os
import sys
import math
import torch
import torch.nn as nn

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from config import (
    DEVICE, RESULTS_DIR,
    BASELINE_CONFIG, ATTENTION_CONFIG, TRANSFORMER_CONFIG,
)
from src.utils.helpers import set_seed
from src.data.loaders import prepare_datasets, build_dataloaders
from src.models.baseline_lstm import BaselineCaptioningModel
from src.models.attention import AttentionCaptioningModel
from src.models.transformer import TransformerCaptioningModel
from src.evaluation.loss import evaluate_loss, perplexity_from_loss
from src.evaluation.bleu import (
    evaluate_bleu_baseline,
    evaluate_bleu_transformer,
)
from src.inference.greedy import greedy_decode_attention


def evaluate_model(name, model, test_loader, criterion, vocab_size,
                   model_type, word2idx, idx2word):
    print(f"\n{'='*60}\nEvaluating: {name}\n{'='*60}")

    test_loss = evaluate_loss(
        model, test_loader, criterion, vocab_size, DEVICE,
        model_type=model_type,
    )
    ppl = perplexity_from_loss(test_loss)

    print(f"Test Loss      : {test_loss:.4f}")
    print(f"Test Perplexity: {ppl:.4f}")

    if model_type == "baseline":
        bleu = evaluate_bleu_baseline(
            model, test_loader, word2idx, idx2word, DEVICE, max_samples=500
        )
    elif model_type == "transformer":
        bleu = evaluate_bleu_transformer(
            model, test_loader, word2idx, idx2word, DEVICE, max_samples=500
        )
    else:  # attention
        # use the attention BLEU helper that supports greedy
        from src.evaluation.bleu import _bleu_scores
        from src.inference.greedy import ids_to_words
        references, hypotheses = [], []
        sample_count = 0
        with torch.no_grad():
            for images, captions, lengths in test_loader:
                images = images.to(DEVICE)
                for i in range(images.size(0)):
                    pred = greedy_decode_attention(
                        model, images[i], word2idx, idx2word, DEVICE
                    )
                    pred_words = pred.split() if pred else ["<unk>"]
                    true_words = ids_to_words(captions[i].tolist(), idx2word)
                    references.append([true_words])
                    hypotheses.append(pred_words)
                    sample_count += 1
                    if sample_count >= 500:
                        break
                if sample_count >= 500:
                    break
        bleu = _bleu_scores(references, hypotheses)

    print(f"BLEU-1: {bleu[0]:.4f} | BLEU-2: {bleu[1]:.4f} | "
          f"BLEU-3: {bleu[2]:.4f} | BLEU-4: {bleu[3]:.4f}")
    return {"test_loss": test_loss, "perplexity": ppl, "bleu": bleu}


def main():
    set_seed(42)

    train_dataset, val_full_dataset, word2idx, idx2word = prepare_datasets()
    _, _, test_loader, _ = build_dataloaders(
        train_dataset, val_full_dataset, word2idx
    )
    vocab_size = len(word2idx)
    pad_idx = word2idx["<pad>"]
    criterion = nn.CrossEntropyLoss(ignore_index=pad_idx)

    # Baseline
    baseline_model = BaselineCaptioningModel(
        embed_dim=BASELINE_CONFIG["embed_dim"],
        hidden_dim=BASELINE_CONFIG["hidden_dim"],
        vocab_size=vocab_size,
        num_layers=BASELINE_CONFIG["num_layers"],
        dropout=BASELINE_CONFIG["dropout"],
    ).to(DEVICE)
    baseline_model.load_state_dict(torch.load(
        os.path.join(RESULTS_DIR, "baseline_lstm_best.pth"), map_location=DEVICE,
    ))
    evaluate_model(
        "Baseline LSTM", baseline_model, test_loader, criterion,
        vocab_size, "baseline", word2idx, idx2word,
    )

    # Attention
    attn_model = AttentionCaptioningModel(
        attention_dim=ATTENTION_CONFIG["attention_dim"],
        embed_dim=ATTENTION_CONFIG["embed_dim"],
        decoder_dim=ATTENTION_CONFIG["decoder_dim"],
        vocab_size=vocab_size,
        dropout=ATTENTION_CONFIG["dropout"],
    ).to(DEVICE)
    attn_model.load_state_dict(torch.load(
        os.path.join(RESULTS_DIR, "best_attention_model.pth"), map_location=DEVICE,
    ))
    evaluate_model(
        "Attention LSTM", attn_model, test_loader, criterion,
        vocab_size, "attention", word2idx, idx2word,
    )

    # Transformer
    trans_model = TransformerCaptioningModel(
        vocab_size=vocab_size,
        pad_idx=pad_idx,
        d_model=TRANSFORMER_CONFIG["d_model"],
        nhead=TRANSFORMER_CONFIG["nhead"],
        num_layers=TRANSFORMER_CONFIG["num_layers"],
        dim_feedforward=TRANSFORMER_CONFIG["dim_feedforward"],
        dropout=TRANSFORMER_CONFIG["dropout"],
        max_len=TRANSFORMER_CONFIG["max_len"],
        fine_tune_encoder=TRANSFORMER_CONFIG["fine_tune_encoder"],
    ).to(DEVICE)
    trans_model.load_state_dict(torch.load(
        os.path.join(RESULTS_DIR, "best_transformer_model.pth"), map_location=DEVICE,
    ))
    evaluate_model(
        "Transformer", trans_model, test_loader, criterion,
        vocab_size, "transformer", word2idx, idx2word,
    )


if __name__ == "__main__":
    main()
