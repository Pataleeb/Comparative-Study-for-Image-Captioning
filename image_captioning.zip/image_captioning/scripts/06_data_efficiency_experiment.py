"""
Script 06: Data efficiency experiment - train all 3 models on
10%, 50%, and 100% of the training data, then measure latency.

Reproduces the cross-model panel (validation loss vs data fraction +
inference latency on log scale) shown in the report.

Usage (from project root):
    python -m scripts.06_data_efficiency_experiment
"""
import os
import sys
import math
import gc
import torch
import torch.nn as nn
import torch.optim as optim

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from config import (
    DEVICE, RESULTS_DIR, DRIVE_ROOT, DATA_REGIMES,
    BASELINE_CONFIG, ATTENTION_CONFIG, TRANSFORMER_CONFIG,
)
from src.utils.helpers import set_seed
from src.data.loaders import (
    prepare_datasets, build_dataloaders, create_subset_loader,
)
from src.models.baseline_lstm import BaselineCaptioningModel
from src.models.attention import AttentionCaptioningModel
from src.models.transformer import TransformerCaptioningModel
from src.training.train_baseline import train_baseline_model
from src.training.train_attention import train_attention_model_best
from src.training.train_transformer import train_transformer_model
from src.evaluation.latency import measure_inference_speed_research
from src.utils.plotting import plot_cross_model_comparison


def run_lstm_regimes(train_loader, val_loader, word2idx):
    pad_idx = word2idx["<pad>"]
    vocab_size = len(word2idx)
    criterion = nn.CrossEntropyLoss(ignore_index=pad_idx)
    results = {}

    for p in DATA_REGIMES:
        regime_name = int(p * 100)
        print(f"\n--- LSTM Baseline | {regime_name}% data ---")
        loader_p = create_subset_loader(train_loader, p)

        model = BaselineCaptioningModel(
            embed_dim=BASELINE_CONFIG["embed_dim"],
            hidden_dim=BASELINE_CONFIG["hidden_dim"],
            vocab_size=vocab_size,
            num_layers=BASELINE_CONFIG["num_layers"],
            dropout=BASELINE_CONFIG["dropout"],
        ).to(DEVICE)

        optimizer = torch.optim.Adam(
            filter(lambda p: p.requires_grad, model.parameters()),
            lr=BASELINE_CONFIG["lr"],
            weight_decay=BASELINE_CONFIG["weight_decay"],
        )

        save_path = os.path.join(RESULTS_DIR, f"best_baseline_lstm_{regime_name}.pth")
        history = {"train_losses": [], "val_losses": []}

        best_loss = train_baseline_model(
            model=model,
            train_loader=loader_p,
            val_loader=val_loader,
            criterion=criterion,
            optimizer=optimizer,
            device=DEVICE,
            num_epochs=BASELINE_CONFIG["num_epochs"],
            save_path=save_path,
            results_dict=history,
        )

        latency = measure_inference_speed_research(model, val_loader, DEVICE)
        results[p] = {
            "best_val_loss": best_loss,
            "latency": latency,
            "history": history,
        }

        del model
        torch.cuda.empty_cache()
        gc.collect()

    return results


def run_attention_regimes(train_loader, val_loader, word2idx):
    results = {}
    for p in DATA_REGIMES:
        regime_name = int(p * 100)
        print(f"\n--- Attention LSTM | {regime_name}% data ---")
        loader_p = create_subset_loader(train_loader, p)

        save_path = os.path.join(RESULTS_DIR, f"best_attention_{regime_name}.pth")
        model, info, _, best_val_loss = train_attention_model_best(
            train_loader=loader_p,
            val_loader=val_loader,
            word2idx=word2idx,
            attention_dim=ATTENTION_CONFIG["attention_dim"],
            embed_dim=ATTENTION_CONFIG["embed_dim"],
            decoder_dim=ATTENTION_CONFIG["decoder_dim"],
            dropout=ATTENTION_CONFIG["dropout"],
            learning_rate=ATTENTION_CONFIG["lr"],
            num_epochs=ATTENTION_CONFIG["num_epochs"],
            device=DEVICE,
            save_path=save_path,
            results_dir=RESULTS_DIR,
        )

        latency = measure_inference_speed_research(model, val_loader, DEVICE)
        results[p] = {
            "best_val_loss": best_val_loss,
            "latency": latency,
            "history": info,
        }

        del model
        torch.cuda.empty_cache()
        gc.collect()

    return results


def run_transformer_regimes(train_loader, val_loader, word2idx):
    pad_idx = word2idx["<pad>"]
    vocab_size = len(word2idx)
    results = {}

    for p in DATA_REGIMES:
        regime_name = int(p * 100)
        print(f"\n--- Transformer | {regime_name}% data ---")
        loader_p = create_subset_loader(train_loader, p)

        model = TransformerCaptioningModel(
            vocab_size=vocab_size,
            pad_idx=pad_idx,
            d_model=TRANSFORMER_CONFIG["d_model"],
            nhead=TRANSFORMER_CONFIG["nhead"],
            num_layers=TRANSFORMER_CONFIG["num_layers"],
            dim_feedforward=TRANSFORMER_CONFIG["dim_feedforward"],
            dropout=TRANSFORMER_CONFIG["dropout"],
            max_len=TRANSFORMER_CONFIG["max_len"],
            fine_tune_encoder=TRANSFORMER_CONFIG["fine_tune_encoder"],
        ).to(DEVICE)

        criterion = nn.CrossEntropyLoss(ignore_index=pad_idx)
        optimizer = optim.Adam(
            filter(lambda p: p.requires_grad, model.parameters()),
            lr=TRANSFORMER_CONFIG["lr"],
            weight_decay=TRANSFORMER_CONFIG["weight_decay"],
        )

        save_path = os.path.join(RESULTS_DIR, f"best_transformer_{regime_name}.pth")
        history = {"train_losses": [], "val_losses": []}

        best_loss = train_transformer_model(
            model=model,
            train_loader=loader_p,
            val_loader=val_loader,
            criterion=criterion,
            optimizer=optimizer,
            device=DEVICE,
            num_epochs=TRANSFORMER_CONFIG["num_epochs"],
            save_path=save_path,
            results_dict=history,
        )

        latency = measure_inference_speed_research(model, val_loader, DEVICE)
        results[p] = {
            "best_val_loss": best_loss,
            "latency": latency,
            "history": history,
        }

        del model
        torch.cuda.empty_cache()
        gc.collect()

    return results


def main():
    set_seed(42)

    train_dataset, val_full_dataset, word2idx, idx2word = prepare_datasets()
    train_loader, val_loader, _, _ = build_dataloaders(
        train_dataset, val_full_dataset, word2idx
    )

    print("=" * 60)
    print("STARTING DATA EFFICIENCY EXPERIMENT")
    print("=" * 60)

    lstm_results = run_lstm_regimes(train_loader, val_loader, word2idx)
    attn_results = run_attention_regimes(train_loader, val_loader, word2idx)
    trans_results = run_transformer_regimes(train_loader, val_loader, word2idx)

    fractions = sorted(DATA_REGIMES)
    lstm_losses = [lstm_results[f]["best_val_loss"] for f in fractions]
    attn_losses = [attn_results[f]["best_val_loss"] for f in fractions]
    trans_losses = [trans_results[f]["best_val_loss"] for f in fractions]

    lstm_lats = [lstm_results[f]["latency"] for f in fractions]
    attn_lats = [attn_results[f]["latency"] for f in fractions]
    trans_lats = [trans_results[f]["latency"] for f in fractions]

    print("\nFinal regime results:")
    for f in fractions:
        print(f"{int(f*100)}% | LSTM={lstm_results[f]['best_val_loss']:.4f}, "
              f"Attn={attn_results[f]['best_val_loss']:.4f}, "
              f"Trans={trans_results[f]['best_val_loss']:.4f}")

    plot_cross_model_comparison(
        attn_losses, lstm_losses, trans_losses,
        attn_lats, lstm_lats, trans_lats,
        save_path=os.path.join(RESULTS_DIR, "final_updated_efficiency_plot.png"),
    )


if __name__ == "__main__":
    main()
