"""
Script 04: Train the Transformer captioning model.

Usage (from project root):
    python -m scripts.04_train_transformer
"""
import os
import sys
import torch
import torch.nn as nn

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from config import DEVICE, RESULTS_DIR, TRANSFORMER_CONFIG
from src.utils.helpers import set_seed
from src.data.loaders import prepare_datasets, build_dataloaders
from src.models.transformer import TransformerCaptioningModel
from src.training.train_transformer import train_transformer_model
from src.utils.plotting import plot_training_curve


def main():
    set_seed(42)

    print("Preparing data...")
    train_dataset, val_full_dataset, word2idx, idx2word = prepare_datasets()
    train_loader, val_loader, _, _ = build_dataloaders(
        train_dataset, val_full_dataset, word2idx
    )

    pad_idx = word2idx["<pad>"]

    print(f"Initializing Transformer | device={DEVICE}")
    model = TransformerCaptioningModel(
        vocab_size=len(word2idx),
        pad_idx=pad_idx,
        d_model=TRANSFORMER_CONFIG["d_model"],
        nhead=TRANSFORMER_CONFIG["nhead"],
        num_layers=TRANSFORMER_CONFIG["num_layers"],
        dim_feedforward=TRANSFORMER_CONFIG["dim_feedforward"],
        dropout=TRANSFORMER_CONFIG["dropout"],
        max_len=TRANSFORMER_CONFIG["max_len"],
        fine_tune_encoder=TRANSFORMER_CONFIG["fine_tune_encoder"],
    ).to(DEVICE)

    criterion = nn.CrossEntropyLoss(ignore_index=pad_idx)
    optimizer = torch.optim.Adam(
        filter(lambda p: p.requires_grad, model.parameters()),
        lr=TRANSFORMER_CONFIG["lr"],
        weight_decay=TRANSFORMER_CONFIG["weight_decay"],
    )

    save_path = os.path.join(RESULTS_DIR, "best_transformer_model.pth")
    history = {"train_losses": [], "val_losses": []}

    best_val_loss = train_transformer_model(
        model=model,
        train_loader=train_loader,
        val_loader=val_loader,
        criterion=criterion,
        optimizer=optimizer,
        device=DEVICE,
        num_epochs=TRANSFORMER_CONFIG["num_epochs"],
        save_path=save_path,
        results_dict=history,
    )

    print(f"\nBest Transformer val loss: {best_val_loss:.4f}")

    plot_training_curve(
        history["train_losses"], history["val_losses"],
        title="Transformer Training vs Validation Loss",
        save_path=os.path.join(RESULTS_DIR, "transformer_loss_curve.png"),
    )


if __name__ == "__main__":
    main()
