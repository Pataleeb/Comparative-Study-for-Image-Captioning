"""
Script 03: Train the Attention LSTM captioning model.

Usage (from project root):
    python -m scripts.03_train_attention
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from config import DEVICE, RESULTS_DIR, ATTENTION_CONFIG
from src.utils.helpers import set_seed
from src.data.loaders import prepare_datasets, build_dataloaders
from src.training.train_attention import train_attention_model_best
from src.utils.plotting import plot_training_curve


def main():
    set_seed(42)

    print("Preparing data...")
    train_dataset, val_full_dataset, word2idx, idx2word = prepare_datasets()
    train_loader, val_loader, _, _ = build_dataloaders(
        train_dataset, val_full_dataset, word2idx
    )

    save_path = os.path.join(RESULTS_DIR, "best_attention_model.pth")

    print(f"Initializing attention LSTM | device={DEVICE}")
    model, results, best_epoch, best_val_loss = train_attention_model_best(
        train_loader=train_loader,
        val_loader=val_loader,
        word2idx=word2idx,
        attention_dim=ATTENTION_CONFIG["attention_dim"],
        embed_dim=ATTENTION_CONFIG["embed_dim"],
        decoder_dim=ATTENTION_CONFIG["decoder_dim"],
        dropout=ATTENTION_CONFIG["dropout"],
        learning_rate=ATTENTION_CONFIG["lr"],
        num_epochs=ATTENTION_CONFIG["num_epochs"],
        device=DEVICE,
        save_path=save_path,
        results_dir=RESULTS_DIR,
    )

    print(f"\nBest attention model: epoch {best_epoch} | val_loss {best_val_loss:.4f}")

    plot_training_curve(
        results["train_loss"], results["val_loss"],
        title="Attention LSTM Training vs Validation Loss",
        save_path=os.path.join(RESULTS_DIR, "attention_loss_curve.png"),
    )


if __name__ == "__main__":
    main()
