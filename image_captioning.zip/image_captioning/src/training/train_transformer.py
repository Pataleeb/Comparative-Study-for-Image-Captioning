"""
Training loop for the Transformer captioning model.

Mirrors the notebook's `train_transformer_model`.
"""
import torch


def train_transformer_model(
    model,
    train_loader,
    val_loader,
    criterion,
    optimizer,
    device,
    num_epochs=10,
    save_path="best_transformer_model.pth",
    results_dict=None,
):
    best_val_loss = float("inf")

    for epoch in range(num_epochs):
        # train
        model.train()
        running_train_loss = 0.0
        for images, captions, lengths in train_loader:
            images = images.to(device)
            captions = captions.to(device)

            optimizer.zero_grad()
            outputs = model(images, captions)
            # model returns (logits, None) tuple
            if isinstance(outputs, tuple):
                outputs = outputs[0]
            targets = captions[:, 1:]

            loss = criterion(
                outputs.reshape(-1, outputs.size(-1)),
                targets.reshape(-1),
            )
            loss.backward()
            optimizer.step()
            running_train_loss += loss.item()

        avg_train_loss = running_train_loss / len(train_loader)

        # validate
        model.eval()
        running_val_loss = 0.0
        with torch.no_grad():
            for images, captions, lengths in val_loader:
                images = images.to(device)
                captions = captions.to(device)

                outputs = model(images, captions)
                if isinstance(outputs, tuple):
                    outputs = outputs[0]
                targets = captions[:, 1:]

                loss = criterion(
                    outputs.reshape(-1, outputs.size(-1)),
                    targets.reshape(-1),
                )
                running_val_loss += loss.item()

        avg_val_loss = running_val_loss / len(val_loader)

        if results_dict is not None:
            results_dict["train_losses"].append(avg_train_loss)
            results_dict["val_losses"].append(avg_val_loss)

        print(
            f"Epoch [{epoch+1}/{num_epochs}] | "
            f"Train Loss: {avg_train_loss:.4f} | "
            f"Val Loss: {avg_val_loss:.4f}"
        )

        if avg_val_loss < best_val_loss:
            best_val_loss = avg_val_loss
            torch.save(model.state_dict(), save_path)
            print(f"Saved best model to {save_path}")

    return best_val_loss
