"""
Training loop for the Attention LSTM captioning model.

Mirrors the notebook's `train_attention_model_best`.
"""
import os
import torch
import torch.nn as nn

from src.models.attention import AttentionCaptioningModel


def train_attention_model_best(
    train_loader,
    val_loader,
    word2idx,
    attention_dim,
    embed_dim,
    decoder_dim,
    dropout,
    learning_rate,
    num_epochs,
    device,
    save_path,
    results_dir,
):
    os.makedirs(results_dir, exist_ok=True)
    vocab_size = len(word2idx)

    model = AttentionCaptioningModel(
        attention_dim=attention_dim,
        embed_dim=embed_dim,
        decoder_dim=decoder_dim,
        vocab_size=vocab_size,
        dropout=dropout,
    ).to(device)

    optimizer = torch.optim.Adam(model.parameters(), lr=learning_rate)
    criterion = nn.CrossEntropyLoss(ignore_index=word2idx.get("<pad>", 0))

    best_val_loss = float("inf")
    best_epoch = 0
    train_losses, val_losses = [], []

    for epoch in range(num_epochs):
        # train
        model.train()
        total_train_loss = 0.0
        for imgs, caps, _ in train_loader:
            imgs = imgs.to(device)
            caps = caps.to(device)

            optimizer.zero_grad()
            outputs, _ = model(imgs, caps[:, :-1])
            targets = caps[:, 1:]

            min_seq_len = min(outputs.size(1), targets.size(1))
            outputs = outputs[:, :min_seq_len, :]
            targets = targets[:, :min_seq_len]

            loss = criterion(
                outputs.reshape(-1, vocab_size),
                targets.reshape(-1),
            )
            loss.backward()
            optimizer.step()
            total_train_loss += loss.item()

        avg_train_loss = total_train_loss / len(train_loader)

        # validate
        model.eval()
        total_val_loss = 0.0
        with torch.no_grad():
            for imgs, caps, _ in val_loader:
                imgs = imgs.to(device)
                caps = caps.to(device)

                outputs, _ = model(imgs, caps[:, :-1])
                targets = caps[:, 1:]

                min_seq_len = min(outputs.size(1), targets.size(1))
                outputs = outputs[:, :min_seq_len, :]
                targets = targets[:, :min_seq_len]

                loss = criterion(
                    outputs.reshape(-1, vocab_size),
                    targets.reshape(-1),
                )
                total_val_loss += loss.item()

        avg_val_loss = total_val_loss / len(val_loader)
        train_losses.append(avg_train_loss)
        val_losses.append(avg_val_loss)

        print(
            f"Epoch {epoch+1}/{num_epochs} | "
            f"Train Loss: {avg_train_loss:.4f} | "
            f"Val Loss: {avg_val_loss:.4f}"
        )

        if avg_val_loss < best_val_loss:
            best_val_loss = avg_val_loss
            best_epoch = epoch + 1
            torch.save(model.state_dict(), save_path)
            print(f"Saved best attention model at epoch {best_epoch}")

    if os.path.exists(save_path):
        model.load_state_dict(torch.load(save_path, map_location=device))

    results = {
        "train_loss": train_losses,
        "val_loss": val_losses,
        "best_epoch": best_epoch,
        "best_val_loss": best_val_loss,
        "dropout": dropout,
        "learning_rate": learning_rate,
    }
    return model, results, best_epoch, best_val_loss
