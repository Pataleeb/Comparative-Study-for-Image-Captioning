"""
Training loop for the baseline LSTM captioning model.

Mirrors the notebook's `train_baseline_model` and `train_epoch_baseline`,
including the safety alignment between outputs and targets.
"""
import torch
import torch.nn as nn


def train_epoch_baseline(model, dataloader, criterion, optimizer, device):
    model.train()
    total_loss = 0.0

    for imgs, caps, caplens in dataloader:
        imgs = (
            torch.stack(imgs).to(device) if isinstance(imgs, list) else imgs.to(device)
        )
        caps = (
            torch.stack(caps).to(device) if isinstance(caps, list) else caps.to(device)
        )

        targets = caps[:, 1:].contiguous()

        optimizer.zero_grad()
        outputs, _ = model(imgs, caps, caplens)

        # Safety alignment: outputs and targets must share the same time dim
        min_seq_len = min(outputs.size(1), targets.size(1))
        outputs = outputs[:, :min_seq_len, :].contiguous()
        targets = targets[:, :min_seq_len].contiguous()

        loss = criterion(
            outputs.view(-1, outputs.size(-1)),
            targets.view(-1),
        )
        loss.backward()
        optimizer.step()
        total_loss += loss.item()

    return total_loss / len(dataloader)


def validate_baseline(model, dataloader, criterion, device):
    model.eval()
    total_loss = 0.0

    with torch.no_grad():
        for imgs, caps, caplens in dataloader:
            imgs = (
                torch.stack(imgs).to(device) if isinstance(imgs, list) else imgs.to(device)
            )
            caps = (
                torch.stack(caps).to(device) if isinstance(caps, list) else caps.to(device)
            )

            targets = caps[:, 1:].contiguous()
            outputs, _ = model(imgs, caps, caplens)

            min_seq_len = min(outputs.size(1), targets.size(1))
            outputs = outputs[:, :min_seq_len, :].contiguous()
            targets = targets[:, :min_seq_len].contiguous()

            loss = criterion(
                outputs.view(-1, outputs.size(-1)),
                targets.view(-1),
            )
            total_loss += loss.item()

    return total_loss / len(dataloader)


def train_baseline_model(model, train_loader, val_loader, criterion, optimizer,
                         device, num_epochs=10,
                         save_path="baseline_lstm_best.pth",
                         results_dict=None):
    """Train a baseline LSTM model and save best checkpoint by val loss."""
    best_val_loss = float("inf")

    for epoch in range(num_epochs):
        train_loss = train_epoch_baseline(model, train_loader, criterion, optimizer, device)
        val_loss = validate_baseline(model, val_loader, criterion, device)

        if results_dict is not None:
            results_dict["train_losses"].append(train_loss)
            results_dict["val_losses"].append(val_loss)

        print(
            f"Epoch [{epoch+1}/{num_epochs}] | "
            f"Train Loss: {train_loss:.4f} | "
            f"Val Loss: {val_loss:.4f}"
        )

        if val_loss < best_val_loss:
            best_val_loss = val_loss
            torch.save(model.state_dict(), save_path)
            print(f"Saved best model to {save_path}")

    return best_val_loss
