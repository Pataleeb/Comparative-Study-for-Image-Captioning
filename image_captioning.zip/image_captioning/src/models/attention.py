"""
Spatial-attention encoder-decoder model (Show, Attend and Tell style).

Uses the conv5 feature map of a frozen ResNet-101 (14x14x2048 by default),
soft attention over spatial locations, and an LSTMCell decoder.
"""
import torch
import torch.nn as nn
import torchvision.models as models


class EncoderCNN_Attention(nn.Module):
    """ResNet-101 spatial feature extractor (frozen) + adaptive pooling."""

    def __init__(self, encoded_image_size=14):
        super().__init__()
        self.enc_image_size = encoded_image_size

        resnet = models.resnet101(weights=models.ResNet101_Weights.DEFAULT)
        modules = list(resnet.children())[:-2]
        self.resnet = nn.Sequential(*modules)

        for param in self.resnet.parameters():
            param.requires_grad = False

        self.adaptive_pool = nn.AdaptiveAvgPool2d(
            (encoded_image_size, encoded_image_size)
        )

    def forward(self, images):
        features = self.resnet(images)              # (B, 2048, H, W)
        features = self.adaptive_pool(features)     # (B, 2048, enc, enc)
        features = features.permute(0, 2, 3, 1)     # (B, enc, enc, 2048)
        return features


class Attention(nn.Module):
    """Additive (Bahdanau-style) soft attention."""

    def __init__(self, encoder_dim, decoder_dim, attention_dim):
        super().__init__()
        self.encoder_att = nn.Linear(encoder_dim, attention_dim)
        self.decoder_att = nn.Linear(decoder_dim, attention_dim)
        self.full_att = nn.Linear(attention_dim, 1)
        self.relu = nn.ReLU()
        self.softmax = nn.Softmax(dim=1)

    def forward(self, encoder_out, decoder_hidden):
        att1 = self.encoder_att(encoder_out)                   # (B, K, A)
        att2 = self.decoder_att(decoder_hidden)                # (B, A)
        att = self.full_att(
            self.relu(att1 + att2.unsqueeze(1))
        ).squeeze(2)                                           # (B, K)
        alpha = self.softmax(att)                              # (B, K)
        attention_weighted_encoding = (
            encoder_out * alpha.unsqueeze(2)
        ).sum(dim=1)                                           # (B, encoder_dim)
        return attention_weighted_encoding, alpha


class DecoderWithAttention(nn.Module):
    """LSTMCell decoder with soft spatial attention and a sentinel gate."""

    def __init__(self, attention_dim, embed_dim, decoder_dim, vocab_size,
                 encoder_dim=2048, dropout=0.5):
        super().__init__()
        self.encoder_dim = encoder_dim
        self.attention_dim = attention_dim
        self.embed_dim = embed_dim
        self.decoder_dim = decoder_dim
        self.vocab_size = vocab_size

        self.attention = Attention(encoder_dim, decoder_dim, attention_dim)
        self.embedding = nn.Embedding(vocab_size, embed_dim)
        self.dropout = nn.Dropout(dropout)
        self.decode_step = nn.LSTMCell(embed_dim + encoder_dim, decoder_dim, bias=True)
        self.init_h = nn.Linear(encoder_dim, decoder_dim)
        self.init_c = nn.Linear(encoder_dim, decoder_dim)
        self.f_beta = nn.Linear(decoder_dim, encoder_dim)
        self.sigmoid = nn.Sigmoid()
        self.fc = nn.Linear(decoder_dim, vocab_size)

    def init_hidden_state(self, encoder_out):
        mean_encoder_out = encoder_out.mean(dim=1)
        h = self.init_h(mean_encoder_out)
        c = self.init_c(mean_encoder_out)
        return h, c

    def forward(self, encoder_out, captions):
        batch_size = encoder_out.size(0)
        encoder_dim = encoder_out.size(-1)

        encoder_out = encoder_out.view(batch_size, -1, encoder_dim)
        num_pixels = encoder_out.size(1)

        embeddings = self.embedding(captions)
        h, c = self.init_hidden_state(encoder_out)

        seq_length = captions.size(1) - 1
        predictions = torch.zeros(
            batch_size, seq_length, self.vocab_size, device=captions.device
        )
        alphas = torch.zeros(
            batch_size, seq_length, num_pixels, device=captions.device
        )

        for t in range(seq_length):
            attention_weighted_encoding, alpha = self.attention(encoder_out, h)
            gate = self.sigmoid(self.f_beta(h))
            attention_weighted_encoding = gate * attention_weighted_encoding

            lstm_input = torch.cat(
                [embeddings[:, t, :], attention_weighted_encoding], dim=1
            )
            h, c = self.decode_step(lstm_input, (h, c))
            preds = self.fc(self.dropout(h))

            predictions[:, t, :] = preds
            alphas[:, t, :] = alpha

        return predictions, alphas


class AttentionCaptioningModel(nn.Module):
    """End-to-end Attention LSTM captioning model."""

    def __init__(self, attention_dim, embed_dim, decoder_dim, vocab_size,
                 encoder_dim=2048, dropout=0.5):
        super().__init__()
        self.encoder = EncoderCNN_Attention()
        self.decoder = DecoderWithAttention(
            attention_dim=attention_dim,
            embed_dim=embed_dim,
            decoder_dim=decoder_dim,
            vocab_size=vocab_size,
            encoder_dim=encoder_dim,
            dropout=dropout,
        )

    def forward(self, images, captions):
        encoder_out = self.encoder(images)
        outputs, alphas = self.decoder(encoder_out, captions)
        return outputs, alphas
