"""
Baseline encoder-decoder model: frozen ResNet-101 -> linear projection ->
single-layer LSTM decoder. No attention.
"""
import torch
import torch.nn as nn
import torchvision.models as models
from torch.nn.utils.rnn import pack_padded_sequence, pad_packed_sequence


class EncoderCNN(nn.Module):
    """Frozen ResNet-101 -> Linear -> BatchNorm to embed_dim."""

    def __init__(self, embed_dim):
        super().__init__()
        resnet = models.resnet101(weights=models.ResNet101_Weights.DEFAULT)
        modules = list(resnet.children())[:-1]
        self.resnet = nn.Sequential(*modules)
        for param in self.resnet.parameters():
            param.requires_grad = False
        self.linear = nn.Linear(resnet.fc.in_features, embed_dim)
        self.bn = nn.BatchNorm1d(embed_dim, momentum=0.01)

    def forward(self, images):
        with torch.no_grad():
            features = self.resnet(images)
        features = features.reshape(features.size(0), -1)
        features = self.bn(self.linear(features))
        return features


class DecoderRNN(nn.Module):
    """Single-layer LSTM decoder conditioned on a global image embedding."""

    def __init__(self, embed_dim, hidden_dim, vocab_size,
                 num_layers=1, dropout=0.5):
        super().__init__()
        self.embed = nn.Embedding(vocab_size, embed_dim)
        self.lstm = nn.LSTM(
            embed_dim, hidden_dim, num_layers,
            batch_first=True,
            dropout=dropout if num_layers > 1 else 0,
        )
        self.linear = nn.Linear(hidden_dim, vocab_size)
        self.dropout = nn.Dropout(dropout)
        self.init_h = nn.Linear(embed_dim, hidden_dim)
        self.init_c = nn.Linear(embed_dim, hidden_dim)

    def forward(self, image_features, captions, lengths=None):
        captions_in = captions[:, :-1]
        embeddings = self.embed(captions_in)

        h0 = self.init_h(image_features).unsqueeze(0)
        c0 = self.init_c(image_features).unsqueeze(0)

        if lengths is None:
            input_lengths = torch.full(
                (captions.size(0),), captions.size(1) - 1, dtype=torch.long
            )
        else:
            if isinstance(lengths, list):
                lengths = torch.tensor(lengths)
            input_lengths = (lengths - 1).cpu()

        packed_inputs = pack_padded_sequence(
            embeddings, input_lengths,
            batch_first=True, enforce_sorted=False,
        )
        packed_outputs, _ = self.lstm(packed_inputs, (h0, c0))
        outputs, _ = pad_packed_sequence(packed_outputs, batch_first=True)

        outputs = self.linear(self.dropout(outputs))
        return (outputs, None)


class BaselineCaptioningModel(nn.Module):
    """End-to-end baseline LSTM captioning model."""

    def __init__(self, embed_dim, hidden_dim, vocab_size,
                 num_layers=1, dropout=0.5):
        super().__init__()
        self.encoder = EncoderCNN(embed_dim)
        self.decoder = DecoderRNN(
            embed_dim, hidden_dim, vocab_size, num_layers, dropout
        )

    def forward(self, images, captions, lengths=None):
        features = self.encoder(images)
        return self.decoder(features, captions, lengths)
