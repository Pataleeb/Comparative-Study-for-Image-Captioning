"""
Transformer-based captioning model.

Frozen ResNet-101 produces a flattened spatial memory, projected to d_model.
A standard nn.TransformerDecoder generates captions auto-regressively with
a causal mask and learned positional encoding.
"""
import math
import torch
import torch.nn as nn
import torchvision.models as models


class EncoderCNNTransformer(nn.Module):
    """ResNet-101 -> flatten spatial -> linear projection to d_model."""

    def __init__(self, d_model, fine_tune=False):
        super().__init__()
        resnet = models.resnet101(weights=models.ResNet101_Weights.DEFAULT)
        modules = list(resnet.children())[:-2]
        self.resnet = nn.Sequential(*modules)

        for param in self.resnet.parameters():
            param.requires_grad = fine_tune

        self.project = nn.Linear(2048, d_model)

    def forward(self, images):
        with torch.no_grad():
            features = self.resnet(images)        # (B, 2048, H, W)
        features = features.flatten(2).permute(0, 2, 1)  # (B, H*W, 2048)
        memory = self.project(features)           # (B, H*W, d_model)
        return memory


class PositionalEncoding(nn.Module):
    """Sinusoidal positional encoding."""

    def __init__(self, d_model, max_len=5000, dropout=0.1):
        super().__init__()
        self.dropout = nn.Dropout(dropout)
        pe = torch.zeros(max_len, d_model)
        position = torch.arange(0, max_len, dtype=torch.float32).unsqueeze(1)
        div_term = torch.exp(
            torch.arange(0, d_model, 2, dtype=torch.float32)
            * (-math.log(10000.0) / d_model)
        )
        pe[:, 0::2] = torch.sin(position * div_term)
        pe[:, 1::2] = torch.cos(position * div_term)
        pe = pe.unsqueeze(0)
        self.register_buffer("pe", pe)

    def forward(self, x):
        x = x + self.pe[:, : x.size(1), :]
        return self.dropout(x)


class TransformerCaptionDecoder(nn.Module):
    """Multi-head self-attention + cross-attention decoder."""

    def __init__(self, vocab_size, pad_idx,
                 d_model=256, nhead=8, num_layers=3,
                 dim_feedforward=512, dropout=0.1, max_len=50):
        super().__init__()
        self.d_model = d_model
        self.pad_idx = pad_idx
        self.embedding = nn.Embedding(vocab_size, d_model, padding_idx=pad_idx)
        self.pos_encoding = PositionalEncoding(d_model, max_len=max_len, dropout=dropout)

        decoder_layer = nn.TransformerDecoderLayer(
            d_model=d_model,
            nhead=nhead,
            dim_feedforward=dim_feedforward,
            dropout=dropout,
            batch_first=True,
        )
        self.transformer_decoder = nn.TransformerDecoder(decoder_layer, num_layers=num_layers)
        self.fc_out = nn.Linear(d_model, vocab_size)
        self.dropout = nn.Dropout(dropout)

    def generate_square_subsequent_mask(self, size, device):
        return torch.triu(
            torch.ones(size, size, device=device, dtype=torch.bool), diagonal=1
        )

    def forward(self, memory, captions):
        tgt = captions[:, :-1]
        tgt_emb = self.embedding(tgt) * math.sqrt(self.d_model)
        tgt_emb = self.pos_encoding(tgt_emb)

        tgt_mask = self.generate_square_subsequent_mask(tgt_emb.size(1), tgt_emb.device)
        tgt_key_padding_mask = (tgt == self.pad_idx)

        out = self.transformer_decoder(
            tgt=tgt_emb,
            memory=memory,
            tgt_mask=tgt_mask,
            tgt_key_padding_mask=tgt_key_padding_mask,
        )
        logits = self.fc_out(self.dropout(out))
        return logits


class TransformerCaptioningModel(nn.Module):
    """End-to-end Transformer captioning model."""

    def __init__(self, vocab_size, pad_idx,
                 d_model=256, nhead=8, num_layers=3,
                 dim_feedforward=512, dropout=0.1, max_len=50,
                 fine_tune_encoder=False):
        super().__init__()
        self.encoder = EncoderCNNTransformer(d_model, fine_tune=fine_tune_encoder)
        self.decoder = TransformerCaptionDecoder(
            vocab_size, pad_idx,
            d_model, nhead, num_layers,
            dim_feedforward, dropout, max_len,
        )

    def forward(self, images, captions, lengths=None):
        memory = self.encoder(images)
        logits = self.decoder(memory, captions)
        return (logits, None)
