"""
Beam search decoding for all three model architectures.
"""
import math
import torch
import torch.nn.functional as F


def beam_search_baseline(model, image, word2idx, idx2word, device,
                         beam_size=3, max_len=20):
    """Beam search for the baseline LSTM model."""
    model.eval()

    start_token = word2idx["<start>"]
    end_token = word2idx["<end>"]

    with torch.no_grad():
        features = model.encoder(image)
        h = model.decoder.init_h(features).unsqueeze(0)
        c = model.decoder.init_c(features).unsqueeze(0)

        sequences = [{
            "tokens": [start_token],
            "score": 0.0,
            "h": h, "c": c,
            "ended": False,
        }]

        for _ in range(max_len):
            all_candidates = []
            for seq in sequences:
                if seq["ended"]:
                    all_candidates.append(seq)
                    continue

                last_word = torch.tensor(
                    [seq["tokens"][-1]], dtype=torch.long
                ).to(device)

                embedding = model.decoder.embed(last_word).unsqueeze(1)
                embedding = model.decoder.dropout(embedding)
                output, (h_new, c_new) = model.decoder.lstm(embedding, (seq["h"], seq["c"]))
                preds = model.decoder.linear(output.squeeze(1))
                log_probs = F.log_softmax(preds, dim=1)

                top_log_probs, top_indices = log_probs.topk(beam_size)

                for i in range(beam_size):
                    next_token = top_indices[0, i].item()
                    next_score = seq["score"] + top_log_probs[0, i].item()
                    all_candidates.append({
                        "tokens": seq["tokens"] + [next_token],
                        "score": next_score,
                        "h": h_new, "c": c_new,
                        "ended": next_token == end_token,
                    })

            sequences = sorted(
                all_candidates,
                key=lambda x: x["score"] / len(x["tokens"]),
                reverse=True,
            )[:beam_size]

            if all(seq["ended"] for seq in sequences):
                break

        best_seq = sequences[0]["tokens"]
        words = []
        for token in best_seq:
            if token == start_token:
                continue
            if token == end_token:
                break
            words.append(idx2word[token])
        return " ".join(words)


def beam_search_attention(model, image, word2idx, idx2word, device,
                          beam_size=3, max_len=20):
    """Beam search for the Attention LSTM model."""
    model.eval()

    start_token = word2idx["<start>"]
    end_token = word2idx["<end>"]

    with torch.no_grad():
        encoder_out = model.encoder(image)

        if encoder_out.dim() == 4:
            if encoder_out.size(-1) == 2048:
                encoder_out = encoder_out.reshape(
                    encoder_out.size(0), -1, encoder_out.size(-1)
                )
            elif encoder_out.size(1) == 2048:
                encoder_out = encoder_out.permute(0, 2, 3, 1)
                encoder_out = encoder_out.reshape(
                    encoder_out.size(0), -1, encoder_out.size(-1)
                )

        h, c = model.decoder.init_hidden_state(encoder_out)

        sequences = [{
            "tokens": [start_token],
            "score": 0.0,
            "h": h, "c": c,
            "ended": False,
        }]

        for _ in range(max_len):
            all_candidates = []
            for seq in sequences:
                if seq["ended"]:
                    all_candidates.append(seq)
                    continue

                last_word = torch.tensor(
                    [seq["tokens"][-1]], dtype=torch.long
                ).to(device)
                embedding = model.decoder.embedding(last_word)

                awe, _ = model.decoder.attention(encoder_out, seq["h"])
                gate = model.decoder.sigmoid(model.decoder.f_beta(seq["h"]))
                awe = gate * awe

                lstm_input = torch.cat([embedding, awe], dim=1)
                h_new, c_new = model.decoder.decode_step(
                    lstm_input, (seq["h"], seq["c"])
                )
                preds = model.decoder.fc(h_new)
                log_probs = F.log_softmax(preds, dim=1)

                top_log_probs, top_indices = log_probs.topk(beam_size)
                for i in range(beam_size):
                    next_token = top_indices[0, i].item()
                    next_score = seq["score"] + top_log_probs[0, i].item()
                    all_candidates.append({
                        "tokens": seq["tokens"] + [next_token],
                        "score": next_score,
                        "h": h_new, "c": c_new,
                        "ended": next_token == end_token,
                    })

            sequences = sorted(
                all_candidates,
                key=lambda x: x["score"] / len(x["tokens"]),
                reverse=True,
            )[:beam_size]

            if all(seq["ended"] for seq in sequences):
                break

        best_seq = sequences[0]["tokens"]
        words = []
        for token in best_seq:
            if token == start_token:
                continue
            if token == end_token:
                break
            words.append(idx2word[token])
        return " ".join(words)


def beam_search_transformer(model, image_tensor, word2idx, idx2word, device,
                            beam_width=5, max_len=20):
    """Beam search for the Transformer model."""
    model.eval()
    start_idx = word2idx["<start>"]
    end_idx = word2idx["<end>"]

    with torch.no_grad():
        image_tensor = image_tensor.unsqueeze(0).to(device)
        memory = model.encoder(image_tensor)
        sequences = [([start_idx], 0.0)]

        for _ in range(max_len):
            all_candidates = []
            for seq, score in sequences:
                if seq[-1] == end_idx:
                    all_candidates.append((seq, score))
                    continue

                tgt = torch.tensor(seq, dtype=torch.long, device=device).unsqueeze(0)
                tgt_emb = model.decoder.embedding(tgt) * math.sqrt(model.decoder.d_model)
                tgt_emb = model.decoder.pos_encoding(tgt_emb)
                tgt_mask = model.decoder.generate_square_subsequent_mask(
                    tgt_emb.size(1), tgt_emb.device
                )
                out = model.decoder.transformer_decoder(
                    tgt=tgt_emb, memory=memory, tgt_mask=tgt_mask,
                )
                logits = model.decoder.fc_out(out[:, -1, :])
                log_probs = torch.log_softmax(logits, dim=-1)

                topk_log_probs, topk_indices = torch.topk(log_probs, beam_width)
                for i in range(beam_width):
                    next_token = topk_indices[0][i].item()
                    new_seq = seq + [next_token]
                    new_score = score + topk_log_probs[0][i].item()
                    all_candidates.append((new_seq, new_score))

            sequences = sorted(all_candidates, key=lambda x: x[1], reverse=True)[:beam_width]

        final_captions = []
        for seq, score in sequences:
            words = []
            for idx in seq[1:]:
                word = idx2word[idx]
                if word == "<end>":
                    break
                if word not in ["<pad>", "<start>"]:
                    words.append(word)
            final_captions.append((" ".join(words), score))
        return final_captions
