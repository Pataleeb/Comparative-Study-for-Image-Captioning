"""
Greedy decoding helpers for all three model architectures.
"""
import math
import torch


def ids_to_words(token_ids, idx2word):
    """Convert token IDs to words, stopping at <end> and skipping specials."""
    words = []
    for idx in token_ids:
        if torch.is_tensor(idx):
            idx = idx.item()
        word = idx2word[idx]
        if word == "<end>":
            break
        if word not in ["<pad>", "<start>"]:
            words.append(word)
    return words


def greedy_decode_baseline(model, image_tensor, word2idx, idx2word,
                           device, max_len=20):
    """Greedy decoding for the baseline LSTM model."""
    model.eval()

    start_idx = word2idx["<start>"]
    end_idx = word2idx["<end>"]
    generated_ids = []
    image_tensor = image_tensor.unsqueeze(0).to(device)

    with torch.no_grad():
        image_features = model.encoder(image_tensor)
        h = model.decoder.init_h(image_features).unsqueeze(0)
        c = model.decoder.init_c(image_features).unsqueeze(0)

        current_token = torch.tensor([start_idx], dtype=torch.long, device=device)
        for _ in range(max_len):
            emb = model.decoder.embed(current_token).unsqueeze(1)
            outputs, (h, c) = model.decoder.lstm(emb, (h, c))
            logits = model.decoder.linear(outputs.squeeze(1))

            next_token = logits.argmax(dim=-1).item()
            generated_ids.append(next_token)
            if next_token == end_idx:
                break
            current_token = torch.tensor(
                [next_token], dtype=torch.long, device=device
            )

    return generated_ids


def greedy_decode_attention(model, image_tensor, word2idx, idx2word,
                            device, max_len=20):
    """Greedy decoding for the Attention LSTM model."""
    model.eval()

    start_idx = word2idx["<start>"]
    end_idx = word2idx["<end>"]

    with torch.no_grad():
        image_tensor = image_tensor.unsqueeze(0).to(device)
        encoder_out = model.encoder(image_tensor)

        # Reshape (B, H, W, C) -> (B, H*W, C)
        if encoder_out.dim() == 4:
            if encoder_out.size(-1) == 2048:
                b, h, w, c = encoder_out.size()
                encoder_out = encoder_out.reshape(b, h * w, c)
            elif encoder_out.size(1) == 2048:
                b, c, h, w = encoder_out.size()
                encoder_out = encoder_out.permute(0, 2, 3, 1).reshape(b, h * w, c)

        h, c = model.decoder.init_hidden_state(encoder_out)

        current_token = torch.tensor([start_idx], dtype=torch.long, device=device)
        generated_ids = []

        for _ in range(max_len):
            embeddings = model.decoder.embedding(current_token)
            awe, alpha = model.decoder.attention(encoder_out, h)
            gate = model.decoder.sigmoid(model.decoder.f_beta(h))
            awe = gate * awe

            lstm_input = torch.cat([embeddings, awe], dim=1)
            h, c = model.decoder.decode_step(lstm_input, (h, c))

            preds = model.decoder.fc(model.decoder.dropout(h))
            next_token = preds.argmax(dim=1).item()

            if next_token == end_idx:
                break
            generated_ids.append(next_token)
            current_token = torch.tensor([next_token], dtype=torch.long, device=device)

    words = [idx2word[idx] for idx in generated_ids]
    return " ".join(words)


def greedy_decode_transformer(model, image_tensor, word2idx, idx2word,
                              device, max_len=20):
    """Greedy decoding for the Transformer model."""
    model.eval()

    start_idx = word2idx["<start>"]
    end_idx = word2idx["<end>"]
    generated = [start_idx]

    with torch.no_grad():
        image_tensor = image_tensor.unsqueeze(0).to(device)
        memory = model.encoder(image_tensor)

        for _ in range(max_len):
            tgt = torch.tensor(generated, dtype=torch.long, device=device).unsqueeze(0)
            tgt_emb = model.decoder.embedding(tgt) * math.sqrt(model.decoder.d_model)
            tgt_emb = model.decoder.pos_encoding(tgt_emb)
            tgt_mask = model.decoder.generate_square_subsequent_mask(
                tgt_emb.size(1), tgt_emb.device
            )
            tgt_key_padding_mask = (tgt == model.decoder.pad_idx)

            out = model.decoder.transformer_decoder(
                tgt=tgt_emb,
                memory=memory,
                tgt_mask=tgt_mask,
                tgt_key_padding_mask=tgt_key_padding_mask,
            )
            logits = model.decoder.fc_out(model.decoder.dropout(out))
            next_token = logits[:, -1, :].argmax(dim=-1).item()

            generated.append(next_token)
            if next_token == end_idx:
                break

    return generated
