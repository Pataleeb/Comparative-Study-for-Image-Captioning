"""
Plotting utilities for training curves and cross-model comparisons.
"""
import os
import numpy as np
import matplotlib.pyplot as plt


def plot_training_curve(train_losses, val_losses, title, save_path):
    """Single-model training vs validation loss curve."""
    epochs = list(range(1, len(train_losses) + 1))

    plt.figure(figsize=(8, 5), facecolor="white")
    plt.plot(epochs, train_losses, marker="o", linestyle="-", label="Train Loss")
    plt.plot(epochs, val_losses, marker="o", linestyle="-", label="Validation Loss")
    plt.xlabel("Epoch")
    plt.ylabel("Loss")
    plt.title(title)
    plt.legend()
    plt.grid(False)

    ax = plt.gca()
    ax.set_facecolor("white")
    plt.tight_layout()

    os.makedirs(os.path.dirname(save_path) or ".", exist_ok=True)
    plt.savefig(save_path, dpi=300, facecolor="white")
    plt.show()


def plot_cross_model_comparison(attn_losses, lstm_losses, trans_losses,
                                attn_lats, lstm_lats, trans_lats,
                                save_path="results/final_updated_efficiency_plot.png"):
    """
    Side-by-side panel:
      - Left: validation loss vs training-data percentage
      - Right: inference latency (log scale) per model x regime
    """
    x_percent = [10, 50, 100]
    percentages = ["10%", "50%", "100%"]

    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(20, 7), facecolor="white")

    # Left: data efficiency
    ax1.plot(x_percent, attn_losses,  label="Attention Model",
             color="#4169E1", marker="o", linewidth=2.5)
    ax1.plot(x_percent, lstm_losses,  label="LSTM Baseline",
             color="#d62728", marker="s", linestyle="--", linewidth=2)
    ax1.plot(x_percent, trans_losses, label="Transformer",
             color="#6a0dad", marker="D", linewidth=2.5)
    ax1.set_title("Cross-Model Data Efficiency Comparison",
                  fontsize=15, fontweight="bold")
    ax1.set_xlabel("Training Data Percentage (%)", fontsize=12)
    ax1.set_ylabel("Validation Loss (Lower is Better)", fontsize=12)
    ax1.grid(True, linestyle=":", alpha=0.6)
    ax1.legend()

    # Right: inference efficiency (log scale)
    x = np.arange(len(percentages))
    width = 0.25
    ax2.set_yscale("log")
    ax2.bar(x - width, attn_lats,  width, label="Attention",
            color="#5f9ea0", alpha=0.9, edgecolor="black")
    ax2.bar(x,         lstm_lats,  width, label="LSTM",
            color="#e7969c", alpha=0.9, edgecolor="black")
    ax2.bar(x + width, trans_lats, width, label="Transformer",
            color="#a28ce3", alpha=0.9, edgecolor="black")

    ax2.set_title("Inference Efficiency (Log Scale for Visibility)",
                  fontsize=15, fontweight="bold")
    ax2.set_xlabel("Training Data Regime", fontsize=12)
    ax2.set_ylabel("Avg Latency (Seconds - Log Scale)", fontsize=12)
    ax2.set_xticks(x)
    ax2.set_xticklabels(percentages)
    ax2.grid(True, which="both", axis="y", linestyle="--", alpha=0.3)
    ax2.legend()

    plt.tight_layout()
    os.makedirs(os.path.dirname(save_path) or ".", exist_ok=True)
    plt.savefig(save_path, dpi=300)
    plt.show()
