"""
Small helper utilities used across scripts.
"""
import random
import numpy as np
import torch


def set_seed(seed: int = 42):
    """Seed Python, NumPy, and PyTorch RNGs for reproducibility."""
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
