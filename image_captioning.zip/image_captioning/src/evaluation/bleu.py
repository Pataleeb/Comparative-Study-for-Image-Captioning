"""
BLEU 1-4 score computation across the three model architectures.

Uses NLTK corpus_bleu with method-1 smoothing.
"""
import math
import torch
from nltk.translate.bleu_score import corpus_bleu, SmoothingFunction

from src.inference.greedy import (
    greedy_decode_baseline,
    greedy_decode_attention,
    greedy_decode_transformer,
    ids_to_words,
)


def _bleu_scores(references, hypotheses):
    """Compute BLEU-1..4 with NLTK smoothing method-1."""
    smoothie = SmoothingFunction().method1
    bleu1 = corpus_bleu(references, hypotheses, weights=(1, 0, 0, 0), smoothing_function=smoothie)
    bleu2 = corpus_bleu(references, hypotheses, weights=(0.5, 0.5, 0, 0), smoothing_function=smoothie)
    bleu3 = corpus_bleu(references, hypotheses, weights=(1/3, 1/3, 1/3, 0), smoothing_function=smoothie)
    bleu4 = corpus_bleu(references, hypotheses, weights=(0.25, 0.25, 0.25, 0.25), smoothing_function=smoothie)
    return bleu1, bleu2, bleu3, bleu4


def evaluate_bleu_baseline(model, test_loader, word2idx, idx2word, device,
                           max_len=20, max_samples=500):
    """Greedy-decode BLEU for the baseline LSTM."""
    model.eval()
    references, hypotheses = [], []
    sample_count = 0

    with torch.no_grad():
        for images, captions, lengths in test_loader:
            images = images.to(device)
            for i in range(images.size(0)):
                pred_ids = greedy_decode_baseline(
                    model, images[i], word2idx, idx2word, device, max_len=max_len
                )
                pred_words = ids_to_words(pred_ids, idx2word)

                true_words = ids_to_words(captions[i].tolist(), idx2word)
                if not pred_words:
                    pred_words = ["<unk>"]

                references.append([true_words])
                hypotheses.append(pred_words)
                sample_count += 1
                if sample_count >= max_samples:
                    break
            if sample_count >= max_samples:
                break

    return _bleu_scores(references, hypotheses)


def evaluate_bleu_attention(model, val_loader, word2idx, idx2word, device,
                            beam_size=3, max_eval=500):
    """Greedy + beam BLEU for the Attention LSTM model."""
    from src.inference.beam_search import beam_search_attention
    from tqdm import tqdm

    model.eval()
    references, greedy_predictions, beam_predictions = [], [], []
    smoothie = SmoothingFunction().method4
    count = 0

    for imgs, caps, _ in tqdm(val_loader):
        imgs = imgs.to(device)
        for i in range(imgs.size(0)):
            if count >= max_eval:
                break
            img = imgs[i].unsqueeze(0)

            ref_tokens = caps[i].tolist()
            ref_words = [
                idx2word[t] for t in ref_tokens
                if t not in [word2idx["<start>"], word2idx["<end>"], word2idx["<pad>"]]
            ]

            greedy_cap = greedy_decode_attention(
                model, imgs[i], word2idx, idx2word, device
            ).split()
            beam_cap = beam_search_attention(
                model, img, word2idx, idx2word, device, beam_size=beam_size
            ).split()

            references.append([ref_words])
            greedy_predictions.append(greedy_cap)
            beam_predictions.append(beam_cap)
            count += 1
        if count >= max_eval:
            break

    results = {}
    for label, preds in [("greedy", greedy_predictions), ("beam", beam_predictions)]:
        results[f"{label}_bleu1"] = corpus_bleu(references, preds, weights=(1, 0, 0, 0), smoothing_function=smoothie)
        results[f"{label}_bleu2"] = corpus_bleu(references, preds, weights=(0.5, 0.5, 0, 0), smoothing_function=smoothie)
        results[f"{label}_bleu3"] = corpus_bleu(references, preds, weights=(1/3, 1/3, 1/3, 0), smoothing_function=smoothie)
        results[f"{label}_bleu4"] = corpus_bleu(references, preds, weights=(0.25, 0.25, 0.25, 0.25), smoothing_function=smoothie)
    results["num_images"] = count
    return results


def evaluate_bleu_transformer(model, test_loader, word2idx, idx2word, device,
                              max_len=20, max_samples=500):
    """Greedy-decode BLEU for the Transformer."""
    model.eval()
    references, hypotheses = [], []
    sample_count = 0

    with torch.no_grad():
        for images, captions, lengths in test_loader:
            images = images.to(device)
            for i in range(images.size(0)):
                pred_ids = greedy_decode_transformer(
                    model, images[i], word2idx, idx2word, device, max_len=max_len
                )
                pred_words = ids_to_words(pred_ids, idx2word)

                true_words = ids_to_words(captions[i].tolist(), idx2word)
                if not pred_words:
                    pred_words = ["<unk>"]

                references.append([true_words])
                hypotheses.append(pred_words)
                sample_count += 1
                if sample_count >= max_samples:
                    break
            if sample_count >= max_samples:
                break

    return _bleu_scores(references, hypotheses)
