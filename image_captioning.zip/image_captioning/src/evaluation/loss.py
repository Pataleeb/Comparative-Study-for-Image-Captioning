"""
Test-set loss and perplexity evaluation.

Works for all three architectures by selecting the appropriate forward pass.
"""
import math
import torch
import torch.nn as nn


def evaluate_loss(model, data_loader, criterion, vocab_size, device,
                  model_type="attention"):
    """
    Compute average cross-entropy loss across `data_loader`.

    `model_type` selects the forward signature:
      - "attention"  -> model(imgs, caps[:,:-1]) returns (logits, alphas)
      - "transformer" -> model(imgs, caps[:,:-1]) returns (logits, None)
      - "baseline"   -> model(imgs, caps[:,:-1]) returns (logits, None)
    """
    model.eval()
    total_loss = 0.0

    with torch.no_grad():
        for images, captions, lengths in data_loader:
            images = images.to(device)
            captions = captions.to(device)

            if model_type == "attention":
                outputs, _ = model(images, captions[:, :-1])
            elif model_type == "transformer":
                outputs = model(images, captions[:, :-1])
                if isinstance(outputs, tuple):
                    outputs = outputs[0]
            elif model_type == "baseline":
                outputs = model(images, captions[:, :-1])
                if isinstance(outputs, tuple):
                    outputs = outputs[0]
            else:
                raise ValueError(
                    "model_type must be: attention, transformer, or baseline"
                )

            targets = captions[:, 1:]

            min_seq_len = min(outputs.size(1), targets.size(1))
            outputs = outputs[:, :min_seq_len, :].contiguous()
            targets = targets[:, :min_seq_len].contiguous()

            loss = criterion(
                outputs.reshape(-1, outputs.size(-1)),
                targets.reshape(-1),
            )
            total_loss += loss.item()

    return total_loss / len(data_loader)


def perplexity_from_loss(loss_value: float) -> float:
    """exp(loss) - undefined for very large losses, caller responsible."""
    return math.exp(loss_value)
