"""
Inference latency measurement using CUDA events for accurate GPU timing.
"""
import numpy as np
import torch


def measure_inference_speed_research(model, dataloader, device, num_samples=100):
    """
    Average per-image latency in seconds, measured with CUDA events.

    Mirrors the notebook's `measure_inference_speed_research` function
    used to produce the inference-efficiency comparison plots.
    """
    model.eval()
    latencies = []

    with torch.no_grad():
        for i, (imgs, caps, caplens) in enumerate(dataloader):
            imgs = (
                torch.stack(imgs).to(device)
                if isinstance(imgs, list)
                else imgs.to(device)
            )
            caps = (
                torch.stack(caps).to(device)
                if isinstance(caps, list)
                else caps.to(device)
            )

            start_event = torch.cuda.Event(enable_timing=True)
            end_event = torch.cuda.Event(enable_timing=True)

            start_event.record()
            _ = model(imgs, caps)
            end_event.record()

            torch.cuda.synchronize()
            latencies.append(
                (start_event.elapsed_time(end_event) / 1000.0) / imgs.size(0)
            )

            if len(latencies) >= num_samples:
                break

    return float(np.mean(latencies))
