"""
DataLoader factory functions.

Centralizes the construction of train / val / test DataLoaders with the
exact split sizes used in the original notebook (20k / 2k / 2k).
"""
import torch
from torch.utils.data import DataLoader, Subset

from config import (
    TRAIN_SUBSET_SIZE,
    VAL_SUBSET_SIZE,
    TEST_SUBSET_SIZE,
    BATCH_SIZE,
    NUM_WORKERS,
    SEED,
    TRAIN_IMAGES_DIR,
    VAL_IMAGES_DIR,
)
from src.data.vocabulary import (
    load_coco_annotations,
    sample_train_subset,
    build_vocabulary,
)
from src.data.dataset import (
    CocoCaptionDataset,
    build_pairs,
    get_transform,
    make_collate_fn,
)


def prepare_datasets():
    """
    Replicates the notebook's data-prep pipeline:
      1. Load train/val annotations
      2. Sample 40k train images
      3. Build pairs and vocabulary
      4. Build val pairs from val2017
    Returns: train_dataset, val_full_dataset, word2idx, idx2word
    """
    train_data, val_data = load_coco_annotations()

    train_images_subset, train_annotations_subset = sample_train_subset(train_data)

    # Build vocabulary first - need raw cleaned pairs
    from src.data.vocabulary import clean_caption
    image_id_to_file = {img["id"]: img["file_name"] for img in train_images_subset}
    raw_train_pairs = []
    import os
    for ann in train_annotations_subset:
        image_id = ann["image_id"]
        if image_id not in image_id_to_file:
            continue
        caption = clean_caption(ann["caption"])
        file_name = image_id_to_file[image_id]
        image_path = os.path.join(TRAIN_IMAGES_DIR, file_name)
        if not os.path.exists(image_path):
            continue
        raw_train_pairs.append((image_path, caption))

    word2idx, idx2word = build_vocabulary(raw_train_pairs)

    # Now build encoded pairs
    train_pairs = build_pairs(
        train_images_subset, train_annotations_subset,
        TRAIN_IMAGES_DIR, word2idx,
    )
    val_pairs = build_pairs(
        val_data["images"], val_data["annotations"],
        VAL_IMAGES_DIR, word2idx,
    )

    transform = get_transform()
    train_dataset = CocoCaptionDataset(train_pairs, transform=transform)
    val_full_dataset = CocoCaptionDataset(val_pairs, transform=transform)

    return train_dataset, val_full_dataset, word2idx, idx2word


def build_dataloaders(train_dataset, val_full_dataset, word2idx,
                      train_size=TRAIN_SUBSET_SIZE,
                      val_size=VAL_SUBSET_SIZE,
                      test_size=TEST_SUBSET_SIZE,
                      batch_size=BATCH_SIZE,
                      num_workers=NUM_WORKERS,
                      seed=SEED):
    """
    Build train/val/test DataLoaders with reproducible Subset selection.
    Test set is drawn from the val2017 split (held out from val_loader).
    """
    pad_idx = word2idx["<pad>"]
    collate_fn = make_collate_fn(pad_idx)

    g = torch.Generator().manual_seed(seed)

    # Train subset
    train_indices = torch.randperm(len(train_dataset), generator=g)[:train_size]
    train_subset = Subset(train_dataset, train_indices)

    # Val/test split from val2017
    g2 = torch.Generator().manual_seed(seed)
    all_val_indices = torch.randperm(len(val_full_dataset), generator=g2)
    val_indices = all_val_indices[:val_size]
    test_indices = all_val_indices[val_size: val_size + test_size]

    val_subset = Subset(val_full_dataset, val_indices)
    test_subset = Subset(val_full_dataset, test_indices)

    train_loader = DataLoader(
        train_subset, batch_size=batch_size, shuffle=True,
        collate_fn=collate_fn, num_workers=num_workers, pin_memory=True,
    )
    val_loader = DataLoader(
        val_subset, batch_size=batch_size, shuffle=False,
        collate_fn=collate_fn, num_workers=num_workers, pin_memory=True,
    )
    test_loader = DataLoader(
        test_subset, batch_size=batch_size, shuffle=False,
        collate_fn=collate_fn, num_workers=num_workers, pin_memory=True,
    )
    return train_loader, val_loader, test_loader, test_subset


def create_subset_loader(base_loader, fraction, seed=SEED):
    """
    Build a DataLoader covering a `fraction` of the underlying dataset.
    Used for the data-efficiency experiment (10% / 50% / 100% regimes).
    """
    if fraction >= 1.0:
        return base_loader

    import numpy as np
    dataset = base_loader.dataset
    num_data = len(dataset)
    indices = list(range(num_data))

    np.random.seed(seed)
    np.random.shuffle(indices)

    subset_size = int(num_data * fraction)
    subset_indices = indices[:subset_size]
    subset_dataset = Subset(dataset, subset_indices)

    return DataLoader(
        subset_dataset,
        batch_size=base_loader.batch_size,
        shuffle=True,
        num_workers=base_loader.num_workers,
        collate_fn=base_loader.collate_fn,
        pin_memory=True,
    )
