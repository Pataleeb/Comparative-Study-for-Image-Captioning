"""
PyTorch Dataset class and image preprocessing pipeline for MS COCO captioning.
"""
import os
import torch
from torch.utils.data import Dataset
from PIL import Image
from torchvision import transforms

from config import (
    BASE_DIR,
    IMAGE_SIZE,
    IMAGENET_MEAN,
    IMAGENET_STD,
)
from src.data.vocabulary import clean_caption, caption_to_sequence


# Image transform - resize, to-tensor, ImageNet normalization
def get_transform():
    return transforms.Compose([
        transforms.Resize((IMAGE_SIZE, IMAGE_SIZE)),
        transforms.ToTensor(),
        transforms.Normalize(mean=IMAGENET_MEAN, std=IMAGENET_STD),
    ])


def build_pairs(images_meta, annotations, image_dir, word2idx):
    """
    Convert raw COCO annotations into a list of (image_path, caption_seq) pairs.
    Skips files that cannot be found on disk.
    """
    image_id_to_file = {img["id"]: img["file_name"] for img in images_meta}
    pairs = []

    for ann in annotations:
        image_id = ann["image_id"]
        if image_id not in image_id_to_file:
            continue

        caption = clean_caption(ann["caption"])
        file_name = image_id_to_file[image_id]
        image_path = os.path.join(image_dir, file_name)

        if not os.path.exists(image_path):
            continue

        seq = caption_to_sequence(caption, word2idx)
        pairs.append((image_path, seq))

    return pairs


class CocoCaptionDataset(Dataset):
    """
    Returns (image_tensor, caption_tensor) for one (image, caption) pair.
    If an image fails to load, a black 224x224 placeholder is returned.
    """

    def __init__(self, data_pairs, transform=None):
        self.data_pairs = data_pairs
        self.transform = transform

    def __len__(self):
        return len(self.data_pairs)

    def __getitem__(self, idx):
        img_path, caption_seq = self.data_pairs[idx]

        try:
            image = Image.open(img_path).convert("RGB")
        except Exception:
            image = Image.new("RGB", (IMAGE_SIZE, IMAGE_SIZE), (0, 0, 0))

        if self.transform:
            image = self.transform(image)

        caption_tensor = torch.tensor(caption_seq, dtype=torch.long)
        return image, caption_tensor


def make_collate_fn(pad_idx: int):
    """
    Build a collate_fn closure that pads variable-length captions with `pad_idx`.
    Returns batches of (images, padded_captions, lengths).
    """
    def collate_fn(batch):
        images, captions = zip(*batch)
        images = torch.stack(images, dim=0)

        lengths = [len(cap) for cap in captions]
        max_len = max(lengths)

        padded_captions = torch.full(
            (len(captions), max_len),
            fill_value=pad_idx,
            dtype=torch.long,
        )
        for i, cap in enumerate(captions):
            padded_captions[i, : len(cap)] = cap

        return images, padded_captions, lengths

    return collate_fn
