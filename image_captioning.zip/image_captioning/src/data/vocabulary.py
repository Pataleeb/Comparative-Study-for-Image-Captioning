"""
Vocabulary construction from MS COCO captions.
Mirrors the original notebook logic verbatim.
"""
import re
import json
import random
from collections import Counter

from config import (
    TRAIN_ANNOT_PATH,
    VAL_ANNOT_PATH,
    SUBSET_IMAGES,
    VOCAB_SIZE,
    SPECIAL_TOKENS,
    SEED,
)


def clean_caption(caption: str) -> str:
    """Lowercase, strip non-alphanumerics, collapse whitespace."""
    caption = caption.lower()
    caption = re.sub(r"[^a-z0-9 ]+", "", caption)
    caption = re.sub(r"\s+", " ", caption).strip()
    return caption


def load_coco_annotations():
    """Load raw MS COCO train/val annotation JSONs."""
    with open(TRAIN_ANNOT_PATH, "r", encoding="utf-8") as f:
        train_data = json.load(f)
    with open(VAL_ANNOT_PATH, "r", encoding="utf-8") as f:
        val_data = json.load(f)
    return train_data, val_data


def sample_train_subset(train_data, n_images=SUBSET_IMAGES, seed=SEED):
    """Sample a fixed-size image subset from train2017 (seeded for reproducibility)."""
    random.seed(seed)
    train_image_ids = [img["id"] for img in train_data["images"]]
    selected_image_ids = set(random.sample(train_image_ids, n_images))

    train_images_subset = [
        img for img in train_data["images"] if img["id"] in selected_image_ids
    ]
    train_annotations_subset = [
        ann for ann in train_data["annotations"]
        if ann["image_id"] in selected_image_ids
    ]
    return train_images_subset, train_annotations_subset


def build_vocabulary(train_pairs, vocab_size=VOCAB_SIZE):
    """
    Build word2idx / idx2word from cleaned training captions.
    Special tokens occupy indices 0..3 in the order:
    <pad>=0, <start>=1, <end>=2, <unk>=3.
    """
    word_counter = Counter()
    for _, caption in train_pairs:
        word_counter.update(caption.split())

    most_common_words = [
        word for word, _ in word_counter.most_common()
        if word not in SPECIAL_TOKENS
    ]
    most_common_words = most_common_words[: vocab_size - len(SPECIAL_TOKENS)]
    vocab_words = SPECIAL_TOKENS + most_common_words

    word2idx = {word: idx for idx, word in enumerate(vocab_words)}
    idx2word = {idx: word for word, idx in word2idx.items()}
    return word2idx, idx2word


def caption_to_sequence(caption: str, word2idx: dict) -> list:
    """Encode a cleaned caption string into [<start>, ..., <end>] index list."""
    start_idx = word2idx["<start>"]
    end_idx = word2idx["<end>"]
    unk_idx = word2idx["<unk>"]
    sequence = [start_idx]
    sequence += [word2idx.get(word, unk_idx) for word in caption.split()]
    sequence.append(end_idx)
    return sequence
