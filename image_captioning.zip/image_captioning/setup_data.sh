#!/usr/bin/env bash
# Downloads MS COCO 2017 (train + val + annotations) into $COCO_BASE_DIR
# (default: /content/data/coco for Colab).
set -e

BASE_DIR="${COCO_BASE_DIR:-/content/data/coco}"
mkdir -p "$BASE_DIR"
cd "$BASE_DIR"

echo "Downloading MS COCO 2017 to $BASE_DIR ..."

wget -q --show-progress http://images.cocodataset.org/zips/train2017.zip
wget -q --show-progress http://images.cocodataset.org/zips/val2017.zip
wget -q --show-progress http://images.cocodataset.org/annotations/annotations_trainval2017.zip

echo "Unzipping ..."
unzip -q train2017.zip
unzip -q val2017.zip
unzip -q annotations_trainval2017.zip

echo "Done. Directory contents:"
ls -la "$BASE_DIR"
